function U_Fused_Image_Generation_Scene(varargin)



run /home/vsharma/Codes/matconvnet/util/vlfeat/toolbox/vl_setup.m;



inputDest = '/cvhci/data/scene_recognition/scene_rgb_nir/unzipped_data/';
fileType  = '*.tiff';
list = getAllFiles(inputDest,fileType,inputDest);


outputDest = '/cvhci/users/vsharma/Data/Fused/Scene';



for i=1:size(list,1)
    
[PATHSTR,NAME,EXT] = fileparts(list{i*2,1});

k = strfind( PATHSTR , '/');
category = PATHSTR(1,k(end)+1:end);

i

% RGB
% RGB = rgbCube(:,:,:,i)/255;
%rgb =  double(imread('0001_rgb.tiff'))/255;
RGB= double(imread(list{i*2,1}))/255;
n1 = size(RGB,1);
n2 = size(RGB,2);

YCBCR = rgb2ycbcr(RGB);
Y_RGB = YCBCR(:,:,1);


% NIR
% Y_NIR = NIR(:,:,i)/255;
%nir = double(imread('0001_nir.tiff'))/255;
Y_NIR = double(imread(list{(i-1)*2+1,1}))/255;
%Y_NIR = imresize(Y_NIR,[n1 n2]);




% BILATERAL FILTERING: Fre_BF
RGBbase_bf= bilateralFilter(Y_RGB);
%  figure, imshow((Ybase));
RGBdetail_bf = Y_RGB - RGBbase_bf;
%  figure,  imshow(mat2gray(Ydetail));
NIRbase_bf = bilateralFilter(Y_NIR);
%  figure, imshow((NIRbase));
NIRdetail_bf = Y_NIR - NIRbase_bf;
%  figure,  imshow(mat2gray(NIRdetail));




% WEIGHTED LEAST SQUARES FILTERING: Viv_WLS
lambda = 0.1;%20.0
alpha  =  1.2; %1.2
% RGB
RGBbase_wls = wlsFilter(YCBCR(:,:,1), lambda, alpha);
% figure, imshow(mat2gray(base_vis));
RGBdetail_wls = YCBCR(:,:,1) - RGBbase_wls;
% figure, imshow(mat2gray(detail_vis));

% NIR
NIRbase_wls = wlsFilter(Y_NIR, lambda, alpha);
% figure, imshow(mat2gray(base_nir));
NIRdetail_wls = Y_NIR - NIRbase_wls;
% figure, imshow(mat2gray(detail_nir));




% New combined version
NIRdetail_bf_Wls_max = max(NIRdetail_bf,NIRdetail_wls);
NIRdetail_bf_Wls_avg = NIRdetail_bf/2 + NIRdetail_wls/2;
% figure, imshow(mat2gray(NIRdetail_bf_Wls));

Ysmooth_bf = NIRdetail_bf + RGBbase_bf; 
Ysmooth_wls = NIRdetail_wls + RGBbase_wls; 
Ysmooth_bf_wls_avg = NIRdetail_bf_Wls_avg +  RGBbase_wls;
% figure,  imshow((Ysmooth_bg_wls));
Ysmooth_bf_wls_max = NIRdetail_bf_Wls_max + max(RGBbase_bf,RGBbase_wls);


% Average{BF,WLS}
YCBCR_bf_wls_avg = zeros(n1,n2,3);
YCBCR_bf_wls_avg(:,:,1) = Ysmooth_bf_wls_avg;
YCBCR_bf_wls_avg(:,:,2) = YCBCR(:,:,2);
YCBCR_bf_wls_avg(:,:,3) = YCBCR(:,:,3);

% BF
YCBCR_bf = YCBCR_bf_wls_avg;
YCBCR_bf(:,:,1) = Ysmooth_bf;

% WLS
YCBCR_wls = YCBCR_bf_wls_avg;
YCBCR_wls(:,:,1) = Ysmooth_wls;

% Max{BF,WLS}
YCBCR_bf_wls_max = YCBCR_bf_wls_avg;
YCBCR_bf_wls_max(:,:,1) = Ysmooth_bf_wls_max;


%%YCbCr to RGB
RGB_bf = ycbcr2rgb(YCBCR_bf);   
RGB_wls = ycbcr2rgb(YCBCR_wls); 
RGB_bf_wls_avg = ycbcr2rgb(YCBCR_bf_wls_avg); 
RGB_bf_wls_max = ycbcr2rgb(YCBCR_bf_wls_max);  


%Sch_WLS
[NIRDetail_Sabine_WLS,Ysmooth_Sabine_WLS, RGB_Sabine_WLS]= Sabine_WLS(RGB,Y_NIR); 


%Sch_WLS
[NIRDetail_fmc, RGB_fmc]= combining_fmc(RGB,Y_NIR);

% Saving image
if ~exist(sprintf('%s/Fre_BF/%s',outputDest,category),'dir')
    mkdir(sprintf('%s/Fre_BF/%s',outputDest,category));
end

if ~exist(sprintf('%s/Viv_WLS/%s',outputDest,category),'dir')
    mkdir(sprintf('%s/Viv_WLS/%s',outputDest,category));
end


if ~exist(sprintf('%s/BF_WLS_Avg/%s',outputDest,category),'dir')
    mkdir(sprintf('%s/BF_WLS_Avg/%s',outputDest,category));
end



if ~exist(sprintf('%s/BF_WLS_Max/%s',outputDest,category),'dir')
    mkdir(sprintf('%s/BF_WLS_Max/%s',outputDest,category));
end



if ~exist(sprintf('%s/Sch_WLS/%s',outputDest,category),'dir')
    mkdir(sprintf('%s/Sch_WLS/%s',outputDest,category));
end


if ~exist(sprintf('%s/Far_WLS/%s',outputDest,category),'dir')
    mkdir(sprintf('%s/Far_WLS/%s',outputDest,category));
end

 
imwrite(RGB_bf,sprintf('%s/Fre_BF/%s/%s_nir.tiff',outputDest,category,NAME),'TIFF'); 
imwrite(RGB_wls,sprintf('%s/Viv_WLS/%s/%s_nir.tiff',outputDest,category,NAME),'TIFF'); 
imwrite(RGB_bf_wls_avg,sprintf('%s/BF_WLS_Avg/%s/%s_nir.tiff',outputDest,category,NAME),'TIFF'); 
imwrite(RGB_bf_wls_max,sprintf('%s/BF_WLS_Max/%s/%s_nir.tiff',outputDest,category,NAME),'TIFF');
imwrite(RGB_Sabine_WLS,sprintf('%s/Sch_WLS/%s/%s_nir.tiff',outputDest,category,NAME),'TIFF');
imwrite(RGB_fmc,sprintf('%s/Far_WLS/%s/%s_nir.tiff',outputDest,category,NAME),'TIFF');


end


end


function [NIRDetail_fmc, RGB_fmc]= combining_fmc(RGB,Y_NIR)

% RGB
rgb = RGB;
cform = makecform('srgb2lab');
lab_rgb = applycform(rgb, cform);
L_rgb = lab_rgb(:,:,1);
a_rgb = lab_rgb(:,:,2);
b_rgb = lab_rgb(:,:,3);

% NIR
L_nir = Y_NIR*100;
% clear all;
% filename = 'flower.png';
% rgb = double(imread(filename))/255;
% cform = makecform('srgb2lab');
% lab = applycform(rgb, cform);
% L = lab(:,:,1);

%% Filter
%tic
L0 = wlsFilter(L_nir, 0.125, 1.2);
%L1 = wlsFilter(L_nir, 0.25, 1.2);
L1 = wlsFilter(L_nir, 0.50,  1.2);
%toc


% figure, imshowpair(L0,mat2gray(L_nir-L0),'montage');
% figure, imshowpair(L1,mat2gray(L_nir-L1),'montage');
% figure, imshowpair(L2,mat2gray(L_nir-L2),'montage');


% imshow(L_nir-L0);
%% Fine
val0 = 25;
val1 = 1;
val2 = 1;
exposure = 1.0;
saturation = 1.1;
gamma = 1.0;

fine = tonemapLAB(L_nir, L0, L1,val0,val1,val2,exposure,gamma,saturation, a_rgb, b_rgb);
%figure, imshow(fine);
% imwrite(fine, 'fine.png');
% imtool(fine);

%% Medium
val0 = 1;
val1 = 40;
val2 = 1;
exposure = 1.0;
saturation = 1.1;
gamma = 1.0;

med = tonemapLAB(L_nir, L0, L1,val0,val1,val2,exposure,gamma,saturation,a_rgb,b_rgb);
%figure, imshow(med);
% imwrite(med, 'medium.png');
% imtool(med);

%% Coarse
val0 = 4;
val1 = 1;
val2 = 15;
exposure = 1.10;
saturation = 1.1;
gamma = 1.0;

coarse = tonemapLAB(L_nir, L0, L1,val0,val1,val2,exposure,gamma,saturation);
% imwrite(coarse, 'coarse.png');
% imtool(coarse);

%% Combining Images

%NIRDetail_fmc = max(fine,max(med,coarse)); % Maximum of three levels

NIRDetail_fmc = fine/3 + med/3 +coarse/3; % Maximum of three levels


%figure, imshow(mat2gray(combined));
% imwrite(combined, 'combined.png');
% imtool(combined);
Lab_new = zeros(size(RGB,1),size(RGB,2),3); 
Lab_new(:,:,1) = NIRDetail_fmc; 
Lab_new(:,:,2) = a_rgb; 
Lab_new(:,:,3) = b_rgb;

RGB_fmc = applycform(Lab_new,makecform('lab2srgb'));
%figure,  imshow(mat2gray(RGB_new));

%figure, imshowpair(rgb,RGB_new,'montage');
end




function [NIRDetail_Sabine_WLS, Ysmooth_Sabine_WLS, RGB_Sabine_WLS]= Sabine_WLS(RGB,Y_NIR)

Vis = RGB;
YCBCR= rgb2ycbcr(Vis);
Vo= YCBCR(:,:,1);

No = Y_NIR;

%% NIR
lambda = 0.1;%20.0
alpha  =  2; %1.2
base_nir0 = wlsFilter(No, lambda, alpha);
detail_nir0 = imdivide(No-base_nir0,base_nir0);
alpha = 4;
base_nir1 = wlsFilter(base_nir0, lambda, alpha);
detail_nir1 = imdivide(base_nir0-base_nir1,base_nir1);
alpha = 8;
base_nir2 = wlsFilter(base_nir1, lambda, alpha);
detail_nir2 = imdivide(base_nir1-base_nir2,base_nir2);
alpha = 16;
base_nir3 = wlsFilter(base_nir2, lambda, alpha);
detail_nir3 = imdivide(base_nir2-base_nir3,base_nir3);
alpha = 32;
base_nir4 = wlsFilter(base_nir3, lambda, alpha);
detail_nir4 = imdivide(base_nir3-base_nir4,base_nir4);
alpha = 64;
base_nir5 = wlsFilter(base_nir4, lambda, alpha);
detail_nir5 = imdivide(base_nir4-base_nir5,base_nir5);


%% RGB
lambda = 0.1;%20.0
alpha  =  2; %1.2
base_vis0 = wlsFilter(Vo, lambda, alpha);
detail_vis0 = imdivide(Vo-base_vis0,base_vis0);
alpha = 4;
base_vis1 = wlsFilter(base_vis0, lambda, alpha);
detail_vis1 = imdivide(base_vis0-base_vis1,base_vis1);
alpha = 8;
base_vis2 = wlsFilter(base_vis1, lambda, alpha);
detail_vis2 = imdivide(base_vis1-base_vis2,base_vis2);
alpha = 16;
base_vis3 = wlsFilter(base_vis2, lambda, alpha);
detail_vis3 = imdivide(base_vis2-base_vis3,base_vis3);
alpha = 32;
base_vis4 = wlsFilter(base_vis3, lambda, alpha);
detail_vis4 = imdivide(base_vis3-base_vis4,base_vis4);
alpha = 64;
base_vis5 = wlsFilter(base_vis4, lambda, alpha);
detail_vis5 = imdivide(base_vis4-base_vis5,base_vis5);


%% Image Fusion

level5 = immultiply(max(detail_vis4,detail_nir4)+1,max(detail_vis5,detail_nir5)+1);
level4 = immultiply(max(detail_vis3,detail_nir3)+1,level5);
level3 = immultiply(max(detail_vis2,detail_nir2)+1,level4);
level2 = immultiply(max(detail_vis1,detail_nir1)+1,level3);
level1 = immultiply(max(detail_vis0,detail_nir0)+1,level2);
level0 = immultiply(base_vis3,level1);
Ysmooth_Sabine_WLS =level0;
NIRDetail_Sabine_WLS = level1;
%figure, imshow(mat2gray(NIRDetail_Sabine_WLS));



%% Combining

YCBCR_new = zeros(size(RGB,1),size(RGB,2),3);
YCBCR_new(:,:,1) = Ysmooth_Sabine_WLS;
YCBCR_new(:,:,2) = YCBCR (:,:,2);
YCBCR_new(:,:,3) = YCBCR (:,:,3);

RGB_Sabine_WLS = ycbcr2rgb(YCBCR_new);
Ysmooth_Sabine_WLS = mat2gray(Ysmooth_Sabine_WLS);


%figure, imshowpair(Ysmooth_Sabine_WLS,RGB_Sabine_WLS,'montage')

end