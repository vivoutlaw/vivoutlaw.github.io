function New_Bands=Beta_Bands(Fixed_Bands,Bands_For_Processing)

Wavelength = Fixed_Bands;
Index_Lambda = Bands_For_Processing;
for i=1:size(Index_Lambda,2)
    if(Wavelength(1,:)~=i)
        Index_Lambda(1,i) = Index_Lambda(1,i); 
    else 
        Index_Lambda(1,i) = 0;
    end
end

Index_Lambda = Index_Lambda';
Index_Lambda(all(~Index_Lambda,2),:) = [];
New_Bands = Index_Lambda';

end