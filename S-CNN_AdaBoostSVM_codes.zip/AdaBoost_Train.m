function [Predictions] = AdaBoost_Train(varargin)

   % load '/esat/nihal/vsharma/Cubes/PolyHK/imdb_approach_2_2_HK_allIMDB';
     load '/esat/nihal/vsharma/Cubes/CMU/imdb_esat_approach_2_2_2_allIMDB';
    clearvars -except features labels_  name_ set_;

    
    %addpath  '/users/visics/vsharma/matlab/libsvm-weights-3.20/matlab/';
    %addpath '/users/visics/vsharma/matlab/libsvm-3.20/matlab/'
    addpath '/users/visics/vsharma/matlab/liblinear-weights-1.96/matlab'
    

    trainSet = 1;
    testSet = 2;

    N = size(find(set_==trainSet),2); % X training labels
    X = labels_;
    
    %W_ = 1 * ones(N,1);
    W_ = (1/N) * ones(N,1); %Weights initialization
    
    % Number of boosting iterations 
    M = 65; 
    
    %Evaluation type
    test= 1; % if band selection , set test=0;
    
    % Required bands
    reqBands = 3;
    
    setup_ = 'CMU';
    front = 0;
    featureExtraction = 'CNN';
    
    
    numEvaltrain = find(set_==trainSet);
    numEvaltest = find(set_==testSet);
    
    
    idx = 1:N;
    acc_ = zeros(M,1);
   
    ratio = 1;
    ratioTrain = floor(size(find(set_==trainSet),2)*ratio);
    ratioTest =size(find(set_==testSet),2);
    
    idx_ = 1:ratioTest;

    W_train = W_(idx(1:ratioTrain),:);
    
    

    

    
    
    

    %AdaBoost Weights
    AdaBoost_Bands = zeros(reqBands,1);
    beta = zeros(reqBands,1);
    
    acc_prior = zeros(M,1);
     
    B = 1:M;
    Z=1;  % For storing priors
    
    for k=1:reqBands
        for m=B
            %Y = single(features(:,(m-1)*628+1:628*m));

        if front==1
            load(sprintf('/esat/nihal/vsharma/Evaluation/extract_HSI_DSIFT_HOG_LBP/%s_%s_Front_Network/%s_%s_Band_%d',setup_,featureExtraction,featureExtraction,setup_,m));
        else 
            load(sprintf('/esat/nihal/vsharma/Evaluation/extract_HSI_DSIFT_HOG_LBP/%s_%s/%s_%s_Band_%d',setup_,featureExtraction,featureExtraction,setup_,m));
        end
        
        if strcmp(featureExtraction,'DSIFT') 
            Y = single(encoding);
        elseif strcmp(featureExtraction,'HOG')
             Y = single(featuresHOG);
        elseif strcmp(featureExtraction,'LBP')
             Y = single(featuresLBP);
        elseif strcmp(featureExtraction,'CNN')
            Y = single(features);
        end

            train_feat = Y(:,numEvaltrain(idx(1:ratioTrain)));
            %train_feat = train_feat / (norm(train_feat,2)+eps);
            train_feat = normr1(train_feat);                    

            %test_feat = Y(:,numEvalSet(idx(1:ratioTest)));

            train_label = X(:,numEvaltrain(idx(1:ratioTrain)));
            %test_label = X(:,numEvalSet(idx(1:ratioTest)));
%             cmd = ['-c ', num2str(C), ' -q '];        

            model = train(double(W_train), double(train_label'), sparse(double(train_feat')),'-c 1000 -q');
            [Xout_tmp0, acc, ~] = predict(double(train_label'), sparse(double(train_feat')),model);
            acc_(m,1) = acc(1);
            Xout(m,:) = Xout_tmp0;
            
          
        end
        
        if Z==1
            acc_prior = acc_;
            Z=Z+1;
        end
        
        temp_Band = find(acc_==max(acc_));

            temp_err=0;

            for i=1:ratioTrain
                if train_label(1,i) ~= Xout(temp_Band,i)
                     temp_err = temp_err + W_train(i,1);
                end
            end
            err = temp_err; 

            alpha = err/(1-err);

            for i=1:ratioTrain
                if train_label(1,i) == Xout(temp_Band,i)
                     W_train(i,1) = W_train(i,1) * alpha;
                end
            end
            W_train = W_train/sum(W_train); 
     

        temp = ~ismember(temp_Band,AdaBoost_Bands,'rows');
        temp_Band = temp.*temp_Band;
        temp_Band(all(~temp_Band,2),:) = [];
        if length(temp_Band)>=1
          chosenBand = temp_Band(find(acc_prior(temp_Band)==max(acc_prior(temp_Band))));
          if length(temp_Band)>1
            chosenBand=chosenBand(end,randperm(size(chosenBand,2), 1));
          end
          AdaBoost_Bands(k,:) = chosenBand;
        end
        B = Beta_Bands(AdaBoost_Bands',1:M);
        acc_ = acc_*.0;
        
        % Output Bands and their corresponding weights
        beta(k,:) = log(1/alpha);
        AdaBoost_Bands
    end

    
    if test ==1
        
        for i=1:size(name_,2)
            temp = name_{i};
            if strfind(temp,'session1')
                set_(:,i)=3; 
            elseif strfind(temp,'_sn1Right_') 
                set_(:,i)=3; 
           elseif strfind(temp,'_sn2Left_')
                set_(:,i)=3;
            else
                
            end
        end 

        trainSet = 3;
        testSet = 2;

        N = size(find(set_==trainSet),2); % X training labels
        X = labels_;

        W_ = (1/N) * ones(N,1); %Weights initialization

        numEvaltrain = find(set_==trainSet);
        numEvaltest = find(set_==testSet);

        idx = 1:N;
        ratio = 1;
        ratioTrain = floor(size(find(set_==trainSet),2)*ratio);
        ratioTest =size(find(set_==testSet),2);

        idx_ = 1:ratioTest;

        W_train = W_(idx(1:ratioTrain),:);
            
    else
        
    end
    
    
    W_train = W_(idx(1:ratioTrain),:);  
    Bands = AdaBoost_Bands';
    k=1;
    for j=Bands
        
        if front==1
            load(sprintf('/esat/nihal/vsharma/Evaluation/extract_HSI_DSIFT_HOG_LBP/%s_%s_Front_Network/%s_%s_Band_%d',setup_,featureExtraction,featureExtraction,setup_,j));
        else 
            load(sprintf('/esat/nihal/vsharma/Evaluation/extract_HSI_DSIFT_HOG_LBP/%s_%s/%s_%s_Band_%d',setup_,featureExtraction,featureExtraction,setup_,j));
        end
        
        Y = single(features);


        train_feat = Y(:,numEvaltrain(idx(1:ratioTrain)));
        %train_feat = train_feat / (norm(train_feat,2)+eps);
        train_feat = normr1(train_feat);   
        train_label = X(:,numEvaltrain(idx(1:ratioTrain)));
        
        if test ==1
            test_feat = Y(:,numEvaltest(idx_(1:ratioTest)));
            test_feat = normr1(test_feat);   
            test_label = X(:,numEvaltest(idx_(1:ratioTest)));
            temp_feat= test_feat;
            temp_label = test_label;
        else
            temp_feat= train_feat;
            temp_label = train_label;
        end
        
%         cmd = ['-c ', num2str(C), ' -q '];        

        model = train(double(W_train),  double(train_label'), sparse(double(train_feat')),'-c 1000 -q');
        [Xout_tmp1, acc, ~] = predict(double(temp_label'), sparse(double(temp_feat')),model);
        Xout_(k,:) = Xout_tmp1;
        k=k+1;
    end
    
    predictedLabel = zeros(size(temp_label,2),1);
    for i=1:size(temp_label,2)
        b=unique(Xout_(:,i));
        numOfPredictedClasses=size(b,1);
        sumof_Beta_predictedClass = zeros(numOfPredictedClasses,1);
        for j=1:numOfPredictedClasses
           sumof_Beta_predictedClass(j,1) = sum(beta(find(Xout_(:,i)==b(j))));
        end
        predictedLabel(i,1) = b(find(sumof_Beta_predictedClass==max(sumof_Beta_predictedClass)),1);
        clear a b numOfPredictedClasses sumof_Beta_predictedClass
    end
    
    Count = zeros(1,1);
    
    for i =1:size(temp_label,2)
        if temp_label(1,i)==predictedLabel(i,1)
            Count = Count+1;
        else
            
        end
    end
    
    Performance = Count/size(temp_label,2)
     
end
