function [net, info] = cnn_viv_app_2(varargin)
% CNN_CIFAR   Demonstrates MatConvNet on CIFAR-10
%    The demo includes two standard model: LeNet and Network in
%    Network (NIN). Use the 'modelType' option to choose one.

run(fullfile(fileparts(mfilename('fullpath')), ...
  '..', 'matlab', 'vl_setupnn.m')) ;

opts.modelType = 'vivnet' ;
%opts.modelType = 'alexnet' ;



[opts, varargin] = vl_argparse(opts, varargin) ;

switch opts.modelType
  case 'vivnet'
    opts.train.learningRate = [0.05*ones(1,15) 0.005*ones(1,10) 0.0005*ones(1,5)] ; % logspace(-2,-4,20)
    opts.train.weightDecay = 0.0005;
  case 'alexnet'
   %opts.train.learningRate = logspace(-1, -4, 20) ;
   opts.train.learningRate = [0.05*ones(1,15) 0.005*ones(1,10) 0.0005*ones(1,5)] ; % logspace(-2,-4,20)
   opts.train.weightDecay = 0.0005;
  otherwise
    error('Unknown model type %s', opts.modelType) ;
end


% Vivek
opts.expDir = fullfile('data', sprintf('PolyHK_Front_Final%s', opts.modelType)) ;
[opts, varargin] = vl_argparse(opts, varargin) ;

opts.train.numEpochs = numel(opts.train.learningRate) ;
[opts, varargin] = vl_argparse(opts, varargin) ;


% Vivek
 
Setup_type = 4;  % 1 -> approach_1 [X,Y,Lambda,No_of_Frames], 2 -> [X,Y,1,Lamda*No_of_Frames] , 3+ -> [X,Y,1,No_of_Frames*Lambda]

opts.esat = '/esat/nihal/vsharma/Cubes/PolyHK'; % or CMU


if Setup_type ==1                              				% [X,Y,Lambda,No_of_Frames]
  opts.imdbPath = fullfile(opts.esat, 'imdb_esat_approach_1.mat'); %imdb_esat_approach_1
  opts.cubePath = fullfile(opts.esat, 'cube_face.mat');
elseif Setup_type ==2                          				% [X,Y,1,lambda*No_of_Frames]
  opts.imdbPath = fullfile(opts.esat, 'imdb_esat_approach_2.mat'); 
  opts.cubePath = fullfile(opts.esat, 'cube_face_2.mat');
elseif Setup_type ==3                                              
    opts.imdbPath = fullfile(opts.esat, 'imdb_esat_approach_2_2_2_allIMDB.mat');
    opts.cubePath = fullfile(opts.esat, 'cube_face_2_2_CMU.mat');
elseif Setup_type ==4                                              
    opts.imdbPath = fullfile(opts.esat, 'imdb_approach_2_2_HK_allIMDB.mat');
    opts.cubePath = fullfile(opts.esat, 'cube_face_2_2_HK.mat');
else
 Setup_type =0;
end



opts.train.batchSize = 25;
opts.train.continue = true ;
opts.train.gpus = 1 ;
opts.train.expDir = opts.expDir ;
opts.useBnorm = true ;
opts = vl_argparse(opts, varargin) ;


if exist(opts.imdbPath, 'file')
  imdb = load(opts.imdbPath) ;
  imdb.face = load(opts.cubePath);
%  imdb.face.cube = face1.cube(:,:,1,imdb.images.id);
end

%clear face1;
%clear imdb.images.id;
%imdb.images.id = [1:size(imdb.face.cube,4)];

% --------------------------------------------------------------------
%                                               Prepare Comparison 1 2
% --------------------------------------------------------------------
%CMU
if Setup_type ==3  
    for i=1:size(imdb.images.name,2)
        temp = imdb.images.name{i};
        if strfind(temp,'session1')
            imdb.images.set(:,i)=3; 
        elseif strfind(temp,'_sn2Center_') 
            imdb.images.set(:,i)=2; 
        elseif strfind(temp,'_sn3Center_')
            imdb.images.set(:,i)=2;
        else
            imdb.images.set(:,i)=1; 
        end
    end
%PolyHK
elseif Setup_type ==4  


 for  ii=1:size(imdb.images.name,2)
        temp = (imdb.images.name{ii});
        if  cell2mat(regexp(temp{1}, '_F_\w*_1', 'match')) 
            imdb.images.set(:,ii)=3; 
        elseif cell2mat(regexp(temp{1}, '_F_\w*_2', 'match')) 
            imdb.images.set(:,ii)=2; 
        elseif cell2mat(regexp(temp{1}, '_F_\w*_3', 'match')) 
            imdb.images.set(:,ii)=2;
        else
            imdb.images.set(:,ii)=1; 
        end
 end



end


% --------------------------------------------------------------------
%                                               Prepare data and model
% --------------------------------------------------------------------


switch opts.modelType
  case 'vivnet' 
      if Setup_type==1
        net = cnn_face_viv_safe(opts);  	%Vivnet Network
      else
          net = cnn_face_viv_app_2_safe(opts);  %cnn_face_viv_app_2_safe(opts)
      end
  case 'alexnet'              
	net = cnn_viv_imagenet(opts);  		% Alexnet Network        
  case 'vgg'
	net = cnn_face_viv_vgg_f(opts);  	% Vgg-f Network 
end


% --------------------------------------------------------------------
%						Subtracting Mean Image
%---------------------------------------------------------------------

%for count=1:1:size(imdb.face.cube,4)
%imdb.face.cube(:,:,:,count) = imdb.face.cube(:,:,:,count) - imdb.meanImage;
%end


% --------------------------------------------------------------------
%                                                                Train
% -------------------------------------------------------------------- 

% getBatchHK or getBatch

[net, info] = cnn_train(net, imdb, @getBatch, ...
    opts.train, ...
    'val', find(imdb.images.set == 2)) ;

