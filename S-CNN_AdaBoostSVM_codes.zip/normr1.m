function [ h_norm ] = normr1(h_un, NORM_TYPE)
%h_un: n*d matrix where n is number of samples and d indicates dimensionality

if (nargin < 2)
    NORM_TYPE = 1;
end

if (NORM_TYPE==-1) h_norm=h_un; return; end; %do nothing

dummy_var = num2cell(h_un,2);
norm_param = num2cell(NORM_TYPE*ones(length(dummy_var),1));
h_norm_value = num2cell( cellfun(@norm, dummy_var, norm_param), 2);
h_norm = cell2mat( cellfun(@(x,y) x./(y+eps), dummy_var, h_norm_value, 'UniformOutput', false) ); 


end

